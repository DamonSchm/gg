import React, { useState } from "react";
import StartScreen from "./components/StartScreen";
import GameScreen from "./components/GameScreen";
import ResultScreen from "./components/ResultScreen";

export default function App() {
  const [stage, setStage] = useState("start");
  const [score, setScore] = useState(0);

  function startGame() {
    setStage("game");
    setScore(0);
  }

  function endGame(finalScore) {
    setScore(finalScore);
    setStage("result");
  }

  function restartGame() {
    setStage("start");
    setScore(0);
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-6">
      <div className="w-full max-w-xl bg-white/80 backdrop-blur rounded-lg shadow-2xl p-8 border border-blue-200">
        {stage === "start" && <StartScreen onStart={startGame} />}
        {stage === "game" && <GameScreen onEnd={endGame} />}
        {stage === "result" && <ResultScreen score={score} onRestart={restartGame} />}
      </div>
      <footer className="mt-8 text-xs text-white opacity-70">
        © 2025 GeoGame. Inspired by GeoGuessr.
      </footer>
    </div>
  );
}