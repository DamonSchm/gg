import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import App from "./App";

// Mock window.scrollTo to prevent errors in jsdom
window.scrollTo = () => {};

describe("GeoGame App", () => {
  it("renders start screen and plays one round", async () => {
    render(<App />);

    // Check for start screen elements
    expect(screen.getByText(/GeoGame/i)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Start Game/i })).toBeInTheDocument();

    // Click start
    fireEvent.click(screen.getByRole("button", { name: /Start Game/i }));

    // Wait for a question to appear
    await waitFor(() => {
      expect(screen.getByText(/Question 1/i)).toBeInTheDocument();
    });

    // Click the first answer (simulate correct/incorrect)
    const answerButtons = screen.getAllByRole("button");
    fireEvent.click(answerButtons.find(btn => btn.textContent.length > 0 && btn.textContent !== "Submit Guess"));

    // Wait for feedback or next question
    await waitFor(() => {
      // You may see "Correct!" or "Incorrect", or it advances to next question
      expect(
        screen.queryByText(/Correct!|Incorrect|Nice!|Too far!/i) ||
        screen.getByText(/Question 2|Game Over/i)
      ).toBeTruthy();
    });
  });
});