import React, { useState } from "react";
import { countries } from "../data/countries";
import { inventions } from "../data/inventions";
import { cities } from "../data/cities";
import { religions } from "../data/religions";
import { wonders } from "../data/wonders";
import MapPinQuestion from "./MapPinQuestion";
import ProgressBar from "./ProgressBar";

// Helper functions
function getRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}
function shuffle(arr) {
  return arr
    .map((v) => ({ v, sort: Math.random() }))
    .sort((a, b) => a.sort - b.sort)
    .map(({ v }) => v);
}
function generateQuestions(num = 7) {
  let questions = [];
  // 1. Capital
  const c1 = getRandom(countries);
  questions.push({
    type: "multiple-choice",
    question: `What is the capital of ${c1.name}?`,
    options: shuffle([
      c1.capital,
      ...countries.filter(c => c.name !== c1.name).slice(0, 3).map(c => c.capital)
    ]),
    answer: c1.capital
  });
  // 2. Flag
  const c2 = getRandom(countries);
  questions.push({
    type: "multiple-choice",
    question: "Which flag is this?",
    flag: c2.flag,
    options: shuffle([
      c2.name,
      ...countries.filter(c => c.name !== c2.name).slice(0, 3).map(c => c.name)
    ]),
    answer: c2.name
  });
  // 3. Outline
  const c3 = getRandom(countries);
  questions.push({
    type: "multiple-choice",
    question: "Which country has this outline?",
    outline: c3.outline,
    options: shuffle([
      c3.name,
      ...countries.filter(c => c.name !== c3.name).slice(0, 3).map(c => c.name)
    ]),
    answer: c3.name
  });
  // 4. Invention origin
  const inv = getRandom(inventions);
  questions.push({
    type: "multiple-choice",
    question: `Which country is the origin of the invention: ${inv.name}?`,
    options: shuffle([
      inv.country,
      ...countries.filter(c => c.name !== inv.country).slice(0, 3).map(c => c.name)
    ]),
    answer: inv.country
  });
  // 5. Religion origin
  const r = getRandom(religions);
  questions.push({
    type: "multiple-choice",
    question: `Where did the religion "${r.name}" originate?`,
    options: shuffle([
      r.origin.country,
      ...countries.filter(c => c.name !== r.origin.country).slice(0, 3).map(c => c.name)
    ]),
    answer: r.origin.country
  });
  // 6. Wonder location
  const w = getRandom(wonders);
  questions.push({
    type: "multiple-choice",
    question: `Where is the "${w.name}" located?`,
    options: shuffle([
      w.country,
      ...countries.filter(c => c.name !== w.country).slice(0, 3).map(c => c.name)
    ]),
    answer: w.country
  });
  // 7. City pin-drop
  const city = getRandom(cities);
  questions.push({
    type: "map-pin",
    question: `Drop a pin where "${city.name}" is located.`,
    answerCoordinates: city.coordinates,
    city: city.name
  });
  return questions;
}

export default function GameScreen({ onEnd }) {
  const [questionIdx, setQuestionIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [questions] = useState(generateQuestions());
  const [answered, setAnswered] = useState(false);
  const [feedback, setFeedback] = useState(null);

  function handleAnswer(selected) {
    if (answered) return;
    const current = questions[questionIdx];
    let isCorrect = false;
    if (current.type === "multiple-choice") {
      isCorrect = selected === current.answer;
      setFeedback(isCorrect ? "Correct!" : `Incorrect. Correct answer: ${current.answer}`);
    } else if (current.type === "map-pin") {
      isCorrect = selected < 100;
      setFeedback(
        isCorrect
          ? "Nice! You were close enough. 🎯"
          : `Too far! You missed by ${Math.round(selected)} km.`
      );
    }
    setScore((s) => s + (isCorrect ? 1 : 0));
    setAnswered(true);
    setTimeout(() => {
      setAnswered(false);
      setFeedback(null);
      if (questionIdx < questions.length - 1) {
        setQuestionIdx(questionIdx + 1);
      } else {
        onEnd(score + (isCorrect ? 1 : 0));
      }
    }, 1450);
  }

  const current = questions[questionIdx];

  return (
    <div>
      <ProgressBar current={questionIdx} total={questions.length} />
      <h2 className="text-2xl font-semibold mb-3 text-blue-800 drop-shadow">Question {questionIdx + 1}</h2>
      <div className="mb-6">
        {current.type === "multiple-choice" && (
          <>
            <p className="text-lg font-medium">{current.question}</p>
            {current.flag && (
              <img src={current.flag} alt="Flag" className="w-36 h-24 my-4 object-contain border rounded-lg shadow" />
            )}
            {current.outline && (
              <img src={current.outline} alt="Country Outline" className="w-44 h-28 my-4 object-contain border rounded" />
            )}
            <div className="grid grid-cols-2 gap-4 mt-4">
              {current.options.map((opt) => (
                <button
                  key={opt}
                  disabled={answered}
                  className={`px-4 py-2 rounded-lg border-2 text-base font-semibold ${
                    answered
                      ? opt === current.answer
                        ? "border-green-400 bg-green-100 text-green-700"
                        : "border-gray-300 bg-gray-100 text-gray-400"
                      : "bg-blue-100 border-blue-200 hover:bg-blue-400 hover:text-white hover:border-blue-600 transition-all"
                  }`}
                  onClick={() => handleAnswer(opt)}
                >
                  {opt}
                </button>
              ))}
            </div>
          </>
        )}
        {current.type === "map-pin" && (
          <MapPinQuestion
            question={current.question}
            answerCoordinates={current.answerCoordinates}
            onAnswered={handleAnswer}
            disabled={answered}
          />
        )}
      </div>
      <div className="flex justify-between items-center">
        <div className="text-sm text-gray-500">Score: {score}</div>
        {feedback && (
          <div
            className={`text-base font-bold ${
              feedback.startsWith("Correct") || feedback.startsWith("Nice") ? "text-green-600" : "text-red-600"
            } animate-pulse`}
          >
            {feedback}
          </div>
        )}
      </div>
    </div>
  );
}