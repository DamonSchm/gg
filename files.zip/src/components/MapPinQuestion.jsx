import React, { useState } from "react";
import { MapContainer, TileLayer, Marker, useMapEvents } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const markerIcon = new L.Icon({
  iconUrl: "https://cdn.jsdelivr.net/npm/leaflet@1.9.3/dist/images/marker-icon.png",
  iconRetinaUrl: "https://cdn.jsdelivr.net/npm/leaflet@1.9.3/dist/images/marker-icon-2x.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34]
});

export default function MapPinQuestion({ question, answerCoordinates, onAnswered, disabled }) {
  const [pin, setPin] = useState(null);

  function MapClicker() {
    useMapEvents({
      click(e) {
        if (!disabled) setPin(e.latlng);
      }
    });
    return null;
  }

  function handleSubmit() {
    if (!pin) return;
    const distance = getDistance(pin.lat, pin.lng, answerCoordinates.lat, answerCoordinates.lng);
    onAnswered(distance);
  }

  function getDistance(lat1, lon1, lat2, lon2) {
    function toRad(x) { return x * Math.PI / 180; }
    const R = 6371;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = Math.sin(dLat / 2) ** 2 +
              Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
              Math.sin(dLon / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  return (
    <div>
      <p className="text-lg font-medium">{question}</p>
      <div className="my-4 rounded overflow-hidden border-2 border-blue-300 shadow" style={{ height: 340 }}>
        <MapContainer center={[20, 0]} zoom={2} style={{ height: "100%", width: "100%" }} scrollWheelZoom>
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution="&copy; OpenStreetMap contributors"
          />
          <MapClicker />
          {pin && <Marker position={[pin.lat, pin.lng]} icon={markerIcon} />}
        </MapContainer>
      </div>
      <button
        className={`px-5 py-2 mt-2 rounded-full font-semibold shadow-md bg-gradient-to-r from-blue-500 to-green-400 text-white text-lg transition-all ${
          !pin || disabled
            ? "opacity-50 cursor-not-allowed"
            : "hover:scale-105 hover:from-blue-600 hover:to-green-500"
        }`}
        onClick={handleSubmit}
        disabled={!pin || disabled}
      >
        Submit Guess
      </button>
      {pin && (
        <div className="mt-2 text-sm text-gray-500">
          Your guess: {pin.lat.toFixed(2)}, {pin.lng.toFixed(2)}
        </div>
      )}
    </div>
  );
}