import React from "react";

export default function ProgressBar({ current, total }) {
  const percent = ((current + 1) / total) * 100;
  return (
    <div className="w-full bg-blue-100 rounded-full h-3 mb-6">
      <div
        className="bg-gradient-to-r from-green-400 to-blue-500 h-3 rounded-full transition-all"
        style={{ width: `${percent}%` }}
      />
    </div>
  );
}