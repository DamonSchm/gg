import React from "react";

export default function ResultScreen({ score, onRestart }) {
  return (
    <div className="flex flex-col items-center gap-6">
      <h2 className="text-4xl font-extrabold text-green-700 drop-shadow">Game Over!</h2>
      <div className="text-2xl font-bold">
        Your score: <span className="text-blue-700">{score}</span>
      </div>
      <button
        className="px-8 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-bold rounded-full shadow-lg text-lg hover:scale-105 hover:from-blue-600 hover:to-indigo-700 transition-all"
        onClick={onRestart}
      >
        Play Again
      </button>
      <p className="text-gray-600 text-sm mt-2">Share your score and challenge friends!</p>
    </div>
  );
}