import React from "react";

export default function StartScreen({ onStart }) {
  return (
    <div className="flex flex-col items-center gap-6">
      <h1 className="text-5xl font-extrabold text-blue-700 drop-shadow mb-2 tracking-tight">GeoGame 🌍</h1>
      <p className="text-gray-700 text-lg text-center max-w-md">
        <span className="font-semibold">Test your global knowledge!</span> Capitals, flags, cities, wonders, inventions, and more. <br />
        Can you get a perfect score?
      </p>
      <button
        className="mt-6 px-8 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-bold rounded-full shadow-lg text-lg hover:scale-105 hover:from-blue-600 hover:to-indigo-700 transition-all"
        onClick={onStart}
      >
        Start Game
      </button>
    </div>
  );
}