export const cities = [
  {
    name: "Cairo",
    country: "Egypt",
    population: 9915000,
    coordinates: { lat: 30.0444, lng: 31.2357 },
    languages: ["Arabic"],
    notable_landmarks: ["Great Pyramid of Giza", "Cairo Citadel"]
  },
  {
    name: "Sydney",
    country: "Australia",
    population: 5312163,
    coordinates: { lat: -33.8688, lng: 151.2093 },
    languages: ["English"],
    notable_landmarks: ["Sydney Opera House", "Harbour Bridge"]
  },
  {
    name: "Rio de Janeiro",
    country: "Brazil",
    population: 6748000,
    coordinates: { lat: -22.9068, lng: -43.1729 },
    languages: ["Portuguese"],
    notable_landmarks: ["Christ the Redeemer", "Sugarloaf Mountain"]
  }
];