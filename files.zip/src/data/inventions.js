export const inventions = [
  {
    name: "Printing Press",
    country: "Germany",
    city: "Mainz",
    year: 1440,
    inventor: "Johannes Gutenberg"
  },
  {
    name: "Telephone",
    country: "United States",
    city: "Boston",
    year: 1876,
    inventor: "Alexander Graham Bell"
  },
  {
    name: "Steam Engine",
    country: "United Kingdom",
    city: "Salford",
    year: 1712,
    inventor: "Thomas Newcomen"
  }
];