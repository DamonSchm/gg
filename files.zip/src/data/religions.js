export const religions = [
  {
    name: "Christianity",
    origin: { country: "Israel", city: "Jerusalem", region: "Middle East" },
    founding_year: 30,
    founder: "Jesus Christ"
  },
  {
    name: "Islam",
    origin: { country: "Saudi Arabia", city: "Mecca", region: "Middle East" },
    founding_year: 610,
    founder: "Muhammad"
  },
  {
    name: "Buddhism",
    origin: { country: "Nepal", city: "Lumbini", region: "South Asia" },
    founding_year: -500,
    founder: "Siddhartha Gautama (Buddha)"
  }
];