export const countries = [
  {
    name: "Canada",
    capital: "Ottawa",
    flag: "https://flagcdn.com/ca.svg",
    population: 38008005,
    languages: ["English", "French"],
    outline: "https://upload.wikimedia.org/wikipedia/commons/d/d9/Canada_blank_map.svg",
    region: "North America"
  },
  {
    name: "Egypt",
    capital: "Cairo",
    flag: "https://flagcdn.com/eg.svg",
    population: 104124440,
    languages: ["Arabic"],
    outline: "https://upload.wikimedia.org/wikipedia/commons/8/87/Egypt_location_map_Blank.svg",
    region: "Africa"
  },
  {
    name: "Australia",
    capital: "Canberra",
    flag: "https://flagcdn.com/au.svg",
    population: 25788217,
    languages: ["English"],
    outline: "https://upload.wikimedia.org/wikipedia/commons/8/88/Australia_blank_map.svg",
    region: "Oceania"
  },
  {
    name: "Brazil",
    capital: "Brasília",
    flag: "https://flagcdn.com/br.svg",
    population: 213993437,
    languages: ["Portuguese"],
    outline: "https://upload.wikimedia.org/wikipedia/commons/4/4f/Brazil_Blank_Map.svg",
    region: "South America"
  }
];