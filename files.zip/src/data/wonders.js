export const wonders = [
  {
    name: "Great Pyramid of Giza",
    country: "Egypt",
    city: "Giza",
    type: "Ancient",
    coordinates: { lat: 29.9792, lng: 31.1342 }
  },
  {
    name: "Christ the Redeemer",
    country: "Brazil",
    city: "Rio de Janeiro",
    type: "Modern",
    coordinates: { lat: -22.9519, lng: -43.2105 }
  },
  {
    name: "Sydney Opera House",
    country: "Australia",
    city: "Sydney",
    type: "Modern",
    coordinates: { lat: -33.8568, lng: 151.2153 }
  }
];